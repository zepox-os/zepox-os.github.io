<h2>Crystal - HTML5 and Bootstrap Website Template</h2>


Crystal is a multi-pages multipurpose html5 and bootstrap website template best for portfolio OR videos displaying websites.

It has a portfolio page which has included bootstratp carousel.

Crystal website template is built on HTML5 CSS3 Bootstrap 5+ and Javascript.

It has used free stock image, font awesome icons

Crystal is a beautiful modern soap style HTML5 and Bootstrap website template with clean code to and well-commented sections to edit them easily.

<b>Crystal has included the different pages</b>

index/home page

about page

contact page

category page

download page

portfolio page (included carousel)

all works (portfolio) page

single page

videos page

404 page
